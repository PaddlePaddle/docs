################
简单案例
################

..  todo::

这里是基于PaddlePaddle实现的简单深度学习入门案例，帮助您更快速的了解飞桨的使用方法，并解决简单深度学习问题，以下是具体的案例详解：

..  toctree::
    :titlesonly:

    fit_a_line/README.cn.md
    recognize_digits/README.cn.md
    word2vec/README.cn.md
