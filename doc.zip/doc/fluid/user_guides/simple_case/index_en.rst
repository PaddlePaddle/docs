############################
Simple Case
############################


..  toctree::
    :titlesonly:

    fit_a_line/README.md
    recognize_digits/README.md
    word2vec/README.md

