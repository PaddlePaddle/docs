################
计算机视觉
################

..  todo::

计算机视觉是一门关于如何运用照相机和计算机来获取我们所需的，被拍摄对象的数据与信息的学问。在这里PaddlePaddle为大家提供了两篇cv的教程供大家学习：

..  toctree::
    :titlesonly:

    image_classification/README.cn.md
    gan/README.cn.md

