################
自然语言处理
################

..  todo::

自然语言处理（Natural Language Processing）是人工智能和语言学领域的分支学科。此领域探讨如何处理及运用自然语言，特别是如何编程计算机以成功处理大量的自然语言数据。在这里PaddlePaddle为大家提供了三篇NLP领域的学习教程：

..  toctree::
    :titlesonly:

    understand_sentiment/README.cn.md
    label_semantic_roles/README.cn.md
    machine_translation/README.cn.md

