################
工具组件
################

..  todo::

这里PaddlePaddle为大家提供了两篇案例文章：百度云分布式训练CTR预估任务和Serving流程一键部署的案例文章，以及飞桨大规模分类库使用的案例文章。


..  toctree::
    :titlesonly:

    elastic_ctr/deploy_ctr_on_baidu_cloud_cn.rst
    plsc/plsc_guider_cn.rst
