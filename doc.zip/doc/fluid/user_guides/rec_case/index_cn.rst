################
推荐
################

..  todo::

推荐系统是利用电子商务网站向客户提供商品信息和建议，帮助用户决定应该购买什么产品，模拟销售人员帮助客户完成购买过程。在这里PaddlePaddle为大家提供了一篇个性化推荐的案例详解：

..  toctree::
    :titlesonly:

    recommender_system/README.cn.md

