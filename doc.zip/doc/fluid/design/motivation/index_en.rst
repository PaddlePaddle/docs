Design Motivations and Goals
--------------------------------------

.. toctree::
  :maxdepth: 1

  api.md
  refactorization.md
  fluid.md
  fluid_compiler.md
