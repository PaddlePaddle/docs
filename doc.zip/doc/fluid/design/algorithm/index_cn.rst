梯度更新算法
------------

.. toctree::
  :maxdepth: 1

  parameter_average.md
