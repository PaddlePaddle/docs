Gradient Update Algorithm
--------------------------------------

.. toctree::
  :maxdepth: 1

  parameter_average.md
