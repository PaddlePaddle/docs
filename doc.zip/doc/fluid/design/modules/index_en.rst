Code Structure and Important Modules
-------------------------------------

.. toctree::
  :maxdepth: 1

  backward.md
  python_api.md
  regularization.md
  infer_var_type.md
  optimizer.md
  prune.md
  register_grad_op.md
  net_op_design.md
