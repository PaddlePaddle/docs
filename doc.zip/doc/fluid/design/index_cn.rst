设计思想
------------

.. toctree::
  :maxdepth: 1

  motivation/index_cn.rst
  execution/index_cn.rst
  concepts/index_cn.rst
  data_type/index_cn.rst
  memory/index_cn.rst
  multi_devices/index_cn.rst
  dynamic_rnn/index_cn.rst
  concurrent/index_cn.rst
  algorithm/index_cn.rst
  network/index_cn.rst
  modules/index_cn.rst
  interface/index_cn.rst
  dist_train/index_cn.rst
