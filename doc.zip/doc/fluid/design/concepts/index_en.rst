Core Concepts
--------------------------------------

.. toctree::
  :maxdepth: 1

  README.md
  cpp_data_feeding.md
  functions_operators_layers.md
  program.md
  variable.md
  var_desc.md
  tensor.md
  tensor_array.md
  lod_tensor.md
  block.md
  scope.md
  executor.md
  parallel_executor.md
