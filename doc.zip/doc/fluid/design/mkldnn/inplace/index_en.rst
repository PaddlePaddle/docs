MKL-DNN IN-PLACE execution support
--------------------------------------

.. toctree::
  :maxdepth: 1

  inplace.md
