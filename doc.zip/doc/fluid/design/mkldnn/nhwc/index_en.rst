MKL-DNN NHWC support
--------------------------------------

.. toctree::
  :maxdepth: 1

  nhwc.md
