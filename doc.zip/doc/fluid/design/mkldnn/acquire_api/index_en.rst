MKL-DNN Acquire API
--------------------------------------

.. toctree::
  :maxdepth: 1

  acquire_api.md
