Dynamic RNN
------------

.. toctree::
  :maxdepth: 1

  rnn.md
  rnn_design_en.md
