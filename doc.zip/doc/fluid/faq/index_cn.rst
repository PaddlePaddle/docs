##############
FAQ
##############

..  toctree::
    :maxdepth: 1

    install_cn.rst
    train_cn.rst
    inference_cn.rst
