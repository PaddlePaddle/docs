==============================
**Compile From Source Code**
==============================

You can also choose to compile and install PaddlePaddle in the way of source code compilation. However, due to the diversity of the native environment, complicated problems may occur when compiling the source code, which may cause your installation to fail. In order to ensure your smooth installation, it is recommended that you prefer the normal installation method.

..	toctree::
	

	compile_Ubuntu_en.md
	compile_CentOS_en.md
	compile_MacOS_en.md
	compile_Windows_en.md
