..  _user_guide_en_:

####################
Advanced User Guides
####################

..  todo::

So far you have already been familiar with PaddlePaddle. And the next expectation, read more on:


    - `Deploy Inference Model  <inference_deployment/index_en.html>`_ ：How to deploy the trained network to perform practical inference


..  toctree::
    :hidden:

    inference_deployment/index_en.rst


