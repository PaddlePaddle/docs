.. PaddlePaddle Fluid documentation master file, created by
   sphinx-quickstart on Thu Jun  7 17:04:53 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

##############
VisualDL 工具
##############

..  toctree::
    :maxdepth: 1


    visualdl.md
    visualdl_usage.md

