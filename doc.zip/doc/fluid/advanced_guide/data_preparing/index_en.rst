..  _user_guide_prepare_data_en:

#############
Prepare Data
#############

This document mainly introduces how to provide data for the network, including Synchronous-method and Asynchronous-method.

.. toctree::
   :maxdepth: 1

   prepare_steps_en.rst
   reader.md
   use_py_reader_en.rst
   feeding_data_en.rst