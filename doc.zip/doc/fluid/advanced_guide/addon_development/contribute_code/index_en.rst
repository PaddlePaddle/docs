#################################
How to contribute codes to Paddle
#################################

..  toctree::
    :maxdepth: 1

    local_dev_guide_en.md
    submit_pr_guide_en.md
