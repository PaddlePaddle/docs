########
进阶指南
########

如果您已经学会使用飞桨来完成常规任务，期望了解更多飞桨在工业部署方面的能力，请阅读：


    - `预测与部署 <../advanced_guide/inference_deployment/index_cn.html>`_ ：介绍如何应用训练好的模型进行预测

..  toctree::
    :hidden:

    inference_deployment/index_cn.rst

