######################
Server-side Deployment
######################

PaddlePaddle provides various methods to support deployment and release of trained models.

.. toctree::
   :titlesonly:

   build_and_install_lib_en.rst
   windows_cpp_inference_en.md
   native_infer_en.md
   paddle_gpu_benchmark_en.md
