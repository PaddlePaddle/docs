############
服务器端部署
############

PaddlePaddle 提供了C++，C和Python的API来支持模型的部署上线。

.. toctree::
   :titlesonly:

   build_and_install_lib_cn.rst
   windows_cpp_inference.md
   native_infer.md
   c_infer_cn.md
   python_infer_cn.md
   
