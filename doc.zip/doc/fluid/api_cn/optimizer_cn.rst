=======================
fluid.optimizer
=======================




..  toctree::
    :maxdepth: 1

    optimizer_cn/Adadelta_cn.rst
    optimizer_cn/AdadeltaOptimizer_cn.rst
    optimizer_cn/Adagrad_cn.rst
    optimizer_cn/AdagradOptimizer_cn.rst
    optimizer_cn/Adam_cn.rst
    optimizer_cn/Adamax_cn.rst
    optimizer_cn/AdamaxOptimizer_cn.rst
    optimizer_cn/AdamOptimizer_cn.rst
    optimizer_cn/DecayedAdagrad_cn.rst
    optimizer_cn/DecayedAdagradOptimizer_cn.rst
    optimizer_cn/DGCMomentumOptimizer_cn.rst
    optimizer_cn/Dpsgd_cn.rst
    optimizer_cn/DpsgdOptimizer_cn.rst
    optimizer_cn/ExponentialMovingAverage_cn.rst
    optimizer_cn/Ftrl_cn.rst
    optimizer_cn/FtrlOptimizer_cn.rst
    optimizer_cn/LambOptimizer_cn.rst
    optimizer_cn/LarsMomentum_cn.rst
    optimizer_cn/LarsMomentumOptimizer_cn.rst
    optimizer_cn/LookaheadOptimizer_cn.rst
    optimizer_cn/ModelAverage_cn.rst
    optimizer_cn/Momentum_cn.rst
    optimizer_cn/MomentumOptimizer_cn.rst
    optimizer_cn/PipelineOptimizer_cn.rst
    optimizer_cn/RecomputeOptimizer_cn.rst
    optimizer_cn/RMSPropOptimizer_cn.rst
    optimizer_cn/SGD_cn.rst
    optimizer_cn/SGDOptimizer_cn.rst
optimizer_cn/AdadeltaOptimizer_cn.rst
optimizer_cn/Adadelta_cn.rst
optimizer_cn/AdagradOptimizer_cn.rst
optimizer_cn/Adagrad_cn.rst
optimizer_cn/AdamaxOptimizer_cn.rst
optimizer_cn/Adamax_cn.rst
optimizer_cn/AdamOptimizer_cn.rst
optimizer_cn/Adam_cn.rst
optimizer_cn/DecayedAdagradOptimizer_cn.rst
optimizer_cn/DecayedAdagrad_cn.rst
optimizer_cn/DGCMomentumOptimizer_cn.rst
optimizer_cn/DpsgdOptimizer_cn.rst
optimizer_cn/Dpsgd_cn.rst
optimizer_cn/ExponentialMovingAverage_cn.rst
optimizer_cn/FtrlOptimizer_cn.rst
optimizer_cn/Ftrl_cn.rst
optimizer_cn/LambOptimizer_cn.rst
optimizer_cn/LarsMomentumOptimizer_cn.rst
optimizer_cn/LarsMomentum_cn.rst
optimizer_cn/LookaheadOptimizer_cn.rst
optimizer_cn/ModelAverage_cn.rst
optimizer_cn/MomentumOptimizer_cn.rst
optimizer_cn/Momentum_cn.rst
optimizer_cn/PipelineOptimizer_cn.rst
optimizer_cn/RecomputeOptimizer_cn.rst
optimizer_cn/RMSPropOptimizer_cn.rst
optimizer_cn/SGDOptimizer_cn.rst
optimizer_cn/SGD_cn.rst
