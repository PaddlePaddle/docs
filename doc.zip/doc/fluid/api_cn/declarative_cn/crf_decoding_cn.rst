.. container:: doc_source

	paddle.fluid.layers.crf_decoding

