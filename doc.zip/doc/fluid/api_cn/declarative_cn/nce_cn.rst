.. container:: doc_source

	paddle.fluid.layers.nce

