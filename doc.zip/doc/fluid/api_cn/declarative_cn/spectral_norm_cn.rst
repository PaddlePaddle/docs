.. container:: doc_source

	paddle.fluid.layers.spectral_norm

