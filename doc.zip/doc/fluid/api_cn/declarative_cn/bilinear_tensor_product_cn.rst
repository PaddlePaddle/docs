.. container:: doc_source

	paddle.fluid.layers.bilinear_tensor_product

