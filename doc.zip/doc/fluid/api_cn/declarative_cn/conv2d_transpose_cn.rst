.. container:: doc_source

	paddle.fluid.layers.conv2d_transpose

