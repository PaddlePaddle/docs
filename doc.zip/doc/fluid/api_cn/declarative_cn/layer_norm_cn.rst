.. container:: doc_source

	paddle.fluid.layers.layer_norm

