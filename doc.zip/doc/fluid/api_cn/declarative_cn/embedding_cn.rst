.. container:: doc_source

	paddle.fluid.input.embedding

