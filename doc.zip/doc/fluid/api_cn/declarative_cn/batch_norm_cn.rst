.. container:: doc_source

	paddle.fluid.layers.batch_norm

