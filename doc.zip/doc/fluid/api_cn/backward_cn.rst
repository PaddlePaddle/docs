=======================
fluid.backward
=======================




..  toctree::
    :maxdepth: 1

    backward_cn/append_backward_cn.rst
    backward_cn/gradients_cn.rst
