.. _cn_api_fluid_release_memory:

release_memory
-------------------------------


.. py:function:: paddle.fluid.release_memory(input_program, skip_opt_set=None)

:api_attr: 声明式编程模式（静态图)



**从1.6版本开始此接口不再推荐使用，请不要在新写的代码中使用它，1.6+版本已默认开启更优的存储优化策略**
