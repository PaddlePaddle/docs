=======================
fluid.regularizer
=======================




..  toctree::
    :maxdepth: 1

    regularizer_cn/L1Decay_cn.rst
    regularizer_cn/L1DecayRegularizer_cn.rst
    regularizer_cn/L2Decay_cn.rst
    regularizer_cn/L2DecayRegularizer_cn.rst
